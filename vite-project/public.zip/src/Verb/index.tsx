interface Definition {
    definition: string;
    example?: string;
}

interface Meaning {
    partOfSpeech: string;
    definitions: Definition[];
}

interface Data {
    meanings: Meaning[];
}

interface VerbProps {
    data: Data[];
    currentTheme: {
        type: string;
        text: string;
        line: string;
        meanSyn: string;
    };
}


const index: React.FC<VerbProps> = ({ currentTheme, data }) => {
    return (
        <>
            <div className='w-[327px] tablet:w-[630px] desktop:w-[736px] h-[71px] mb-1 flex flex-row justify-between items-center gap-[2px] tablet:gap-2'>
                <p className={`${currentTheme.type} mb-1 text-[18px] tablet:text-[24px] font-bold`}><i>verb</i></p>
                <div className={`${currentTheme.line} w-[266px] tablet:w-[608px] desktop:w-[656px] h-[1px]`}></div>
            </div>
            {(data[0]?.meanings[0]?.partOfSpeech || data[0]?.meanings[1]?.partOfSpeech) === 'verb' ?
                (
                    <>
                        <p className={`${currentTheme.meanSyn} w-[327px] mb-3 desktop:mb-[25px] text-[16px] tablet:text-[20px] font-extralight`}>Meaning</p>
                        <ul className={`${currentTheme.text} w-[327px] tablet:w-[630px] desktop:w-[736px] min-h mb-6 desktop:mb-[30px] flex flex-col justify-start list-disc marker:(--strong-purple)`}>
                            {(data[0]?.meanings[0] || data[0].meanings[1] || data[1]?.meanings[0] )
                                ?.filter((meaning: Meaning) => meaning.partOfSpeech === "verb")
                                .flatMap((meaning: Meaning) =>
                                    meaning.definitions.map((definition: Definition, index: number) => (
                                        <li
                                            key={index}
                                            className='ml-5 mobile:mb-[6px] tablet:ml-[35px] desktop:ml-[35px] desktop:mb-2'
                                        >
                                            {definition.definition || "No definition available"}
                                        </li>
                                    ))
                                )}
                        </ul>
                        <div className='w-[327px] tablet:w-[630px] desktop:mb-[40px] min-h-[30px] mb-10 flex flex-col gap-3'>
                            <p className='text-(--medium-gray) text-[16px]'>
                                "{data[1]?.meanings[0]?.definitions[0]?.example || data[0]?.meanings[0]?.definitions[0]?.example || data[0]?.meanings[1]?.definitions[0]?.example}"
                            </p>
                        </div>
                    </>
                )
                :
                (
                    <>
                        <p className={`${currentTheme.text} mobile:w-[327px] tablet:w-[600px] desktop:w-[730px] mb-5`}>
                            Sorry, there is no verb definition available for this word. Please try another one.
                        </p>
                    </>
                )
            }

        </>
    )
}

export default index